# number-thinker-project
My First .sh Game!
A simple .sh game made to run in a linux terminal.
#Installation Guide
1. Download the tar.gz file and extract it
2. Locate the exact directory and run `./install.sh`
3. You're Good to go **Remember:** To run the program type `./install.sh`
